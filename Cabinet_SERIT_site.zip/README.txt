Cabinet SERIT – Site vitrine (instructions rapides)
==================================================

1) Ouvrir localement
--------------------
- Double-cliquez sur index.html pour l’ouvrir dans votre navigateur (Chrome / Edge / Firefox).

2) Mettre en ligne gratuitement
-------------------------------
- Netlify : faites glisser-déposer le fichier index.html sur https://app.netlify.com/drop
- GitHub Pages : créez un dépôt public, uploadez index.html, puis activez Pages (branch main, /root).

3) Personnaliser
----------------
- Modifiez les coordonnées (email, téléphone) dans la section #contact.
- Changez les textes des sections “Qui sommes-nous ?”, “Nos pôles”, “Services”, “Atouts” selon vos besoins.
- Pour un formulaire qui envoie sans client mail, utilisez un service comme Formspree ou un backend PHP.

Contact : contact@cabinetserit.com
